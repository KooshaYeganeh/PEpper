# colors for output
BLUE = '\033[94m'
GREEN = '\033[32m'
RED = '\033[91m'
DEFAULT = '\033[39m'
ORANGE = '\033[33m'
WHITE = '\033[97m'
YELLOW = '\033[93m'
