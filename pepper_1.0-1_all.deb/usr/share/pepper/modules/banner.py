from . import colors

# what script would be without a banner?


def get():
    print(colors.GREEN + " _____  ______ " +
          colors.RED + "                      ")
    print(colors.GREEN + "|  __ \|  ____|" +
          colors.RED + "                      ")
    print(colors.GREEN + "| |__) | |__   " +
          colors.RED + " _ __  _ __   ___ _ __ ")
    print(colors.GREEN + "|  ___/|  __|  " +
          colors.RED + "| '_ \| '_ \ / _ \ '__|")
    print(colors.GREEN + "| |    | |____ " +
          colors.RED + "| |_) | |_) |  __/ |   ")
    print(colors.GREEN + "|_|    |______|" +
          colors.RED + "| .__/| .__/ \___|_|   ")
    print(colors.GREEN + "               " +
          colors.RED + "| |   | |              ")
    print(colors.GREEN + "               " +
          colors.RED + "|_|   |_|              ")
    print((colors.BLUE + "\n Th3Hurrican3\n\n" + colors.DEFAULT))
